#' the \pkg{PramCurry} package
#' 
#' @description This package was built as an aide for analysis of 
#'   \emph{Phytophthora ramorum} isolates from the Curry County, Oregon epidemic
#'   from 2001 to 2014. It contains tools that work mainly with the \R package 
#'   \pkg{poppr} and will be incorporated into \pkg{poppr} in the future. 
#'   
#'   \strong{NOTE: This package is not intended for use with any other data set.}
#'   
#' @section Data sets:
#' There are two main data sets in this package:
#'   \itemize{ \item{\code{\link{ramdat}} - }{\emph{P. ramorum} forest
#'   genotypes} \item{\code{\link{for2nur}} - }{\emph{P. ramorum} forest and
#'   nursery genotypes} } 
#'   
#' @section Metadata:
#' Metadata includes mainly color
#'   palettes: \itemize{ \item{\code{\link{myPal}} - }{a color palette for each
#'   one of the 70 MLGs in \code{\link{ramdat}}} \item{\code{\link{comparePal}}
#'   - }{a color palette for each population defined in \code{\link{for2nur}}} }
#' @section Functions:
#' \subsection{data manipulation, and utilities}{
#'  These functions
#'   simply manipulate data and/or provide utilites. See descritpions for
#'   details. \itemize{ \item{\code{\link{char2pal}}} \item{\code{\link{fix_replen}}} \item{\code{\link{get_layout}}} 
#'   \item{\code{\link{get_ranges}}} \item{\code{\link{lazierLoad}}} \item{\code{\link{match_duplicates}}} 
#'   \item{\code{\link{merge_duplicates}}} \item{\code{\link{mlgFromString}}} \item{\code{\link{pad_zeroes}}} 
#'   \item{\code{\link{plot_posterior}}} \item{\code{\link{prepare_mlg_df}}} \item{\code{\link{remove_the_edges}}} 
#'   \item{\code{\link{resetMLG}}} \item{\code{\link{test_replen}}} \item{\code{\link{update_my_graph}}} }}
#' \subsection{data analysis}{
#'   These functions will perform some sort of data analysis.
#'   \itemize{ 
#'   \item{\code{\link{begin_end}}} \item{\code{\link{boot_ci}}} \item{\code{\link{calc_loc_table}}} \item{\code{\link{do_boot}}} 
#'   \item{\code{\link{get_stats}}} \item{\code{\link{mlg.barplot}}} \item{\code{\link{mlg.heatmap}}} \item{\code{\link{MLG_range}}} 
#'   \item{\code{\link{plot_loc_table}}} \item{\code{\link{population_subgraph}}} \item{\code{\link{spatial_stats}}} }} 
#'   
#' @author Zhian N. Kamvar
#' @references ZN Kamvar, MM Larsen, AM Kanaskie, EM Hansen and NJ Grünwald. 
#'   20XX. Spatial and temporal population dynamics of the sudden oak death 
#'   epidemic in Oregon Forests. Phytopathology XX:XXX-XXX.
#'   
#'   Kamvar ZN, Tabima JF, Grünwald NJ. (2014) Poppr: an R package for genetic
#'   analysis of populations with clonal, partially clonal, and/or sexual
#'   reproduction. PeerJ 2:e281 http://dx.doi.org/10.7717/peerj.281
#' @name PramCurry-package
#' @aliases PramCurry
#' @docType package
NULL