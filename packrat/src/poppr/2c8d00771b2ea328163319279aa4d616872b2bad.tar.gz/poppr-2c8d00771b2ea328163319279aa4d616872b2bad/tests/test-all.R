library(testthat)
test_check("poppr")