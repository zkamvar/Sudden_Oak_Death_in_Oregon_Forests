## zzz.R 

.packageName <- "phangorn"

.aamodels <- c("WAG", "JTT", "LG", "Dayhoff", "cpREV", "mtmam", "mtArt", "MtZoa", "mtREV24", "VT","RtREV", "HIVw", "HIVb", "FLU","Blossum62","Dayhoff_DCMut","JTT_DCMut")

.onLoad  <- function(libname, pkgname) {
    library.dynam("phangorn", pkgname, libname)
}

