library(testthat)
#library(mmod)

test_package("mmod")
